import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt

class MLP:
    def __init__(self, n_inputs, n_hidden, n_outputs, lr=0.01):
        self.W1 = np.random.randn(n_inputs, n_hidden)
        self.b1 = np.zeros((1, n_hidden))
        self.W2 = np.random.randn(n_hidden, n_outputs)
        self.b2 = np.zeros((1, n_outputs))
        self.lr = lr

    def sigmoid(self, x): return 1 / (1 + np.exp(-x))
    def dsigmoid(self, x): return x * (1 - x)
    def softmax(self, x): 
        e = np.exp(x - np.max(x, axis=1, keepdims=True))
        return e / np.sum(e, axis=1, keepdims=True)

    def forward(self, X):
        self.z1 = X @ self.W1 + self.b1
        self.a1 = self.sigmoid(self.z1)
        self.z2 = self.a1 @ self.W2 + self.b2
        self.a2 = self.softmax(self.z2)
        return self.a2

    def backward(self, X, y):
        m = X.shape[0]
        y_onehot = np.zeros_like(self.a2)
        y_onehot[np.arange(m), y] = 1
        dz2 = (self.a2 - y_onehot) / m
        dW2 = self.a1.T @ dz2
        db2 = np.sum(dz2, axis=0, keepdims=True)
        dz1 = dz2 @ self.W2.T * self.dsigmoid(self.a1)
        dW1 = X.T @ dz1
        db1 = np.sum(dz1, axis=0, keepdims=True)
        self.W1 -= self.lr * dW1
        self.b1 -= self.lr * db1
        self.W2 -= self.lr * dW2
        self.b2 -= self.lr * db2

    def train(self, X, y, epochs=100):
        losses = []
        for _ in range(epochs):
            out = self.forward(X)
            loss = -np.mean(np.log(out[np.arange(len(y)), y] + 1e-8))
            losses.append(loss)
            self.backward(X, y)
        return losses

    def predict(self, X):
        return np.argmax(self.forward(X), axis=1)

data = pd.read_csv("student_performance.csv")
X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values

scaler = StandardScaler()
X = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

mlp = MLP(n_inputs=X.shape[1], n_hidden=8, n_outputs=len(np.unique(y)), lr=0.1)
losses = mlp.train(X_train, y_train, epochs=200)

y_pred = mlp.predict(X_test)
print("Accuracy:", accuracy_score(y_test, y_pred))

plt.plot(losses)
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.show()
